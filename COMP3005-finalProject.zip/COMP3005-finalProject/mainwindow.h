#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public slots:
    void customerOrOwner();
    void mainMenuOptions();
    void showBasket();
    void addBookToCart();
    void removeBookFromCart();
    void addBookToLibrary();
    void removeBookFromLibrary();
    void selectByGenre();
    void salesAndExpenditure();
    void keywordSearch();
    void keywordEdit();


public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
