#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>
#include <sqlite3.h>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    /*
     * Information for connecting DB was found here
     * geeksforgeeks.org/sql-using-c-c-and-sqlite/
     *
sqlite3* DB;
int exit = 0;
exit = sqlite3_open("comp3005finaldatabase.db", &DB);

if (exit){
    std::cerr << "Error opening database" << sqlite3_errmsg(DB);
    //return -1;
} else {
    std::cout << "Successfully opened database " << std::endl;
    sqlite3_close(DB);
   // return 0;
   }

   std::string sql = "CREATE TABLE USER("
                     "USER_ID       TEXT    NOT NULL, "
                     "ADDRESS       TEXT    CHAR(50), "
                     "NAME          TEXT    TEXT    ); ";

   std::string sql = "CREATE TABLE VISITS("
                     "USER_ID       INT     NOT NULL, "
                     "STORE_NAME    TEXT    NOT NULL ); ";

   std::string sql = "CREATE TABLE BOOKSTORE("
                     "STORE_NAME    TEXT    NOT NULL, "
                     "ADDRESS       TEXT    TEXT     ); ";

   std::string sql = "CREATE TABLE PUBLISHER("
                     "PUBLISHER_ID  INT     NOT NULL, "
                     "ADDRESS       TEXT    CHAR(50), "
                     "EMAIL         TEXT    CHAR(50), "
                     "NAME          TEXT    NOT NULL ); ";

   std::string sql = "CREATE TABLE CREATED("
                     "PUBLISHER_ID  INT     NOT NULL, "
                     "ISBN          INT     NOT NULL ); ";

   std::string sql = "CREATE TABLE OWNER("
                     "OWNER_ID      INT     NOT NULL, "
                     "EMAIL         TEXT    CHAR(50), "
                     "NAME          TEXT    CHAR(50) ); ";

   std::string sql = "CREATE TABLE OWNS("
                     "OWNER_ID      INT     NOT NULL, "
                     "STORE_NAME    TEXT    NOT NULL ); ";

   std::string sql = "CREATE TABLE BOOK("
                     "ISBN          INT     NOT NULL, "
                     "TITLE         TEXT    CHAR(50), "
                     "AUTHOR        TEXT    CHAR(50), "
                     "PAGE_NUMBER   INT     NOT NULL), "
                     "GENRE         TEXT    NOT NULL ); ";
*/


    connect(ui->custOrOwn, SIGNAL(activated(int)), this, SLOT(customerOrOwner()));
    connect(ui->mainMenuListWidget, SIGNAL(clicked(QModelIndex)), this, SLOT(mainMenuOptions()));
    connect(ui->viewBasketButton, SIGNAL(clicked(bool)), this, SLOT(showBasket()));
    connect(ui->addtoCartButton, SIGNAL(clicked(bool)), this, SLOT(addBookToCart()));
    connect(ui->removeFromCartButton, SIGNAL(clicked(bool)), this, SLOT(removeBookFromCart()));
    connect(ui->addBookButton, SIGNAL(clicked(bool)), this, SLOT(addBookToLibrary()));
    connect(ui->removeBookButton, SIGNAL(clicked(bool)), this, SLOT(removeBookFromLibrary()));
    connect(ui->transactionButton, SIGNAL(activated(int)), this, SLOT(selectByGenre()));
    connect(ui->salesVEx, SIGNAL(clicked(bool)), this, SLOT(salesAndExpenditure()));
    connect(ui->keywordComboBox, SIGNAL(activated(int)), this, SLOT(keywordSearch()));
    connect(ui->keywordTextEdit, SIGNAL(textChanged()), this,SLOT(keywordEdit()));



//Initially hide all options
       ui->ownerPrivledges->hide();
       ui->addBookButton->hide();
       ui->removeBookButton->hide();
       ui->salesVEx->hide();
       ui->transactionButton->hide();
       ui->transactionsWords->hide();

       ui->addtoCartButton->hide();
       ui->removeFromCartButton->hide();
       ui->viewBasketButton->hide();
       ui->customerWord->hide();
}

void MainWindow::keywordEdit(){
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->addItem("You are attempting to search by keyword: ");
    ui->mainMenuListWidget->addItem(ui->keywordComboBox->currentText());
    ui->mainMenuListWidget->addItem(ui->keywordTextEdit->toPlainText());

}

void MainWindow::keywordSearch(){
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->addItem("You have selected to search by keyword: ");
    ui->mainMenuListWidget->addItem(ui->keywordComboBox->currentText());
}

void MainWindow::salesAndExpenditure(){
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->addItem("You have selected sales and expenditure. \nPlease stand by.");
}

void MainWindow::addBookToLibrary(){
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->addItem("Please select a book to add to the library");

}

void MainWindow::removeBookFromLibrary(){
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->addItem("Please select a book to remove from the library");

}

void MainWindow::addBookToCart(){
    ui->mainMenuListWidget->takeItem(3);
            ui->mainMenuListWidget->takeItem(3);
            ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->addItem("Please select a book to add to your cart");

}

void MainWindow::selectByGenre(){
        ui->mainMenuListWidget->takeItem(3);
        ui->mainMenuListWidget->takeItem(3);
ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->addItem("You have chosen to select transactions according to: ");
    ui->mainMenuListWidget->addItem(ui->transactionButton->currentText());

}

void MainWindow::removeBookFromCart(){
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->addItem("Please select a book to remove from your cart");

}

void MainWindow::showBasket(){
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->takeItem(3);
    ui->mainMenuListWidget->addItem("There are currently no items in your bsaket");
}

void MainWindow::mainMenuOptions(){
    if (ui->mainMenuListWidget->currentItem()->text() == "Search Entire Database"){
        ui->mainMenuListWidget->takeItem(3);
        ui->mainMenuListWidget->takeItem(3);
        ui->mainMenuListWidget->takeItem(3);
        ui->mainMenuListWidget->addItem("There are currently no items in the database");
    }

    if (ui->mainMenuListWidget->currentItem()->text() == "Search by Keyword"){
        ui->mainMenuListWidget->takeItem(3);
        ui->mainMenuListWidget->takeItem(3);
        ui->mainMenuListWidget->takeItem(3);
        ui->mainMenuListWidget->addItem("There are currently no items in the database");

    }

}

void MainWindow::customerOrOwner(){

    //QString customerConvert = "Customer";



    if (ui->custOrOwn->currentText() == "Customer"){
         //qInfo("Hi");
        ui->ownerPrivledges->hide();
         ui->addBookButton->hide();
          ui->removeBookButton->hide();
           ui->salesVEx->hide();
            ui->transactionButton->hide();
            ui->transactionsWords->hide();

            ui->addtoCartButton->show();
            ui->removeFromCartButton->show();
            ui->viewBasketButton->show();
            ui->customerWord->show();
    }

    if (ui->custOrOwn->currentText() == "Owner"){
        //qInfo("Hi");
       ui->ownerPrivledges->show();
        ui->addBookButton->show();
         ui->removeBookButton->show();
          ui->salesVEx->show();
           ui->transactionButton->show();
           ui->transactionsWords->show();

           ui->addtoCartButton->hide();
           ui->removeFromCartButton->hide();
           ui->viewBasketButton->hide();
           ui->customerWord->hide();



    }

}

MainWindow::~MainWindow()
{
    delete ui;
}

